
int parser_ClienteFromText(FILE* pFile, LinkedList* pArrayListCliente);




