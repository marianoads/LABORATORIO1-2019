#include <stdio.h>
#include <stdlib.h>
typedef struct
{
    int id;
    char name[51];
    char lastName[51];
    float salary;
    int sector;
    int isEmpty;
} eEmployee;

void newEmployee(eEmployee vec[],int tam);
void showEmployee(eEmployee vec[],int tam);
void initializeEmployee(eEmployee vec[], int tam);
int searchEmployee(eEmployee vec[],int tam);

int main()
{


    eEmployee empleado[100];

    int opcion;
    char seguir = 's';
    printf("/////////////// ABM //////////////");
    while(seguir=='s')
    {
        initializeEmployee(empleado, 100);

        printf("\n\n1-ALTA\n2-BAJA\n3-ORDENAR\n4-INFORMAR\n5-SALIR\n\nIngrese opcion :");
        scanf("%d", &opcion);

        switch(opcion)
        {
        case 1:
            newEmployee(empleado,100);
            break;
        case 2:
            showEmployee(empleado,100);
            system("pause");
            break;
        case 3:
            break;
        case 4:
            break;
        case 5:
            seguir = 'n';
            break;
        default:
            printf("Ingrese una opcion correcta (1-5)");
            break;

        }

    }



    return 0;
}

void newEmployee(eEmployee vec[],int tam)
{

    int indiceLibre;
    indiceLibre = searchEmployee(vec,tam);

    if(indiceLibre==-1)
    {
        printf("NO HAY MAS LUGAR EN EL SISTEMA !");
    }
    else
    {
        printf("Ingrese nombre :");
        scanf("%s",vec[1].name);

    }


}

void showEmployee(eEmployee vec[],int tam)
{
    printf("El nombre es :%s\n", vec[1].name);

}

void initializeEmployee(eEmployee vec[], int tam)
{
    for(int i=0; i<tam; i++)
    {
        vec[i].isEmpty=0;
    }
}

int searchEmployee(eEmployee vec[],int tam)
{
    for(int i=0; i< tam; i++)
    {
        if(vec[i].isEmpty==0)
        {
            return i;
        }
    }
    return -1;
}
