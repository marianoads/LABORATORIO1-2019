#ifndef EMPLEADO_H_INCLUDED
#define EMPLEADO_H_INCLUDED
typedef struct
{
    int id;
    char name[51];
    char lastName[51];
    float salary;
    int sector;
    int isEmpty;
} eEmployee;

void addEmployee(eEmployee vec[],int tam);
void showEmployee(eEmployee vec[],int tam);
void initializeEmployee(eEmployee vec[], int tam);
void modificationMenu (eEmployee vec[],int tam);
void removeEmployee(eEmployee vec[],int tam);
int searchForFreeSpace(eEmployee vec[],int tam);
int findEmployeeById(eEmployee vec[], int tam,int id);
int someActiveEmployee(eEmployee vec[],int tam);


#endif // EMPLEADO_H_INCLUDED
