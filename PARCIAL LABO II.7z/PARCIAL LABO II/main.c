#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "Controller.h"
#include "Employee.h"

/****************************************************
    Menu:
     1. Cargar los datos de los empleados desde el archivo data.csv (modo texto).
     2. Cargar los datos de los empleados desde el archivo mayoresDe30.csv (modo texto).
     3. Guardar los datos de los empleados en el archivo data.csv (modo texto).
     4. Guardar los datos de los empleados en el archivo mayoresDe30.csv (modo texto).

    10. Salir
*****************************************************/


int main()
{
    int option=0;
    char seguir='s';

    LinkedList* listaEmpleados = ll_newLinkedList();

    LinkedList* nuevaLista = ll_newLinkedList();




    while(seguir=='s')
    {
        printf("ABM EMPLEADOS\n\n");
        printf("1-Cargar datos de los empleados desde el archivo data.csv (modo texto)\n");
        printf("2-Cargar datos de los empleados desde el archivo mayoresDe30.csv (modo texto)\n");
        printf("3-Mostrar el archivo data.csv\n");
        printf("4-Mostrar el archivo mayoresDe30.csv\n");
        printf("5-Guardar los datos de los empleados en el archivo data.csv (modo texto)\n");
        printf("6-Guardar los datos de los empleados en el archivo mayoresDe30.csv (modo texto)\n");
        printf("7-Salir\n\n");

        printf("Ingrese opcion : ");
        scanf("%d", &option);


        switch(option)
        {
        case 1:
            controller_loadFromText("data.csv",listaEmpleados);

            break;
        case 2:
            controller_loadFromText("mayoresDe30.csv",listaEmpleados);
            break;
        case 3:
            controller_showEmployees(listaEmpleados,ll_len(listaEmpleados));
            break;
        case 4:

            break;
        case 5:

            break;
        case 6:

            break;
        case 7:
            seguir= 'n';
            break;



        default:
            printf("Ingrese opcion correcta 1-10\n");
        }
        getch();
        system("cls");
    }

    return 0;
}
