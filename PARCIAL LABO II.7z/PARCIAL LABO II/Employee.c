#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "Employee.h"
#include "LinkedList.h"



int employee_setId(Employee* this,int id)
{

    int todoOk = 0;

    if( this != NULL && id > 0)
    {

        this->id = id;
        todoOk = 1;
    }

    return todoOk;
}

int employee_getId(Employee* this,int* id)
{

    int todoOk = 0;

    if( this != NULL && id != NULL )
    {

        *id = this->id;
        todoOk = 1;
    }
    return todoOk;
}


int employee_setNombre(Employee* this,char* nombre)
{

    int todoOk = 0;

    if( this != NULL && nombre != NULL && strlen(nombre) > 2)
    {

        strcpy(this->nombre, nombre);
        todoOk = 1;
    }

    return todoOk;

}



int employee_getNombre(Employee* this,char* nombre)
{

    int todoOk = 0;

    if( this != NULL && nombre != NULL )
    {

        strcpy(nombre, this->nombre);
        todoOk = 1;
    }

    return todoOk;

}

int employee_setProfesion(Employee* this,char* profesion)
{

    int todoOk = 0;

    if( this != NULL && profesion != NULL && strlen(profesion) >= 6)
    {

        strcpy(this->profesion, profesion);
        todoOk = 1;
    }

    return todoOk;

}

int employee_getProfesion(Employee* this,char* profesion)
{

    int todoOk = 0;

    if( this != NULL && profesion != NULL )
    {

        strcpy(profesion, this->profesion);
        todoOk = 1;
    }

    return todoOk;

}


int employee_setEdad(Employee* this,int edad)
{

    int todoOk = 0;

    if( this != NULL && edad > 0)
    {

        this->edad = edad;
        todoOk = 1;
    }

    return todoOk;
}

int employee_getEdad(Employee* this,int* edad)
{
    int todoOk = 0;

    if( this != NULL && edad != NULL )
    {

        *edad = this->edad;
        todoOk = 1;
    }
    return todoOk;
}




int employee_setSueldo(Employee* this,int sueldo)
{

    int todoOk = 0;

    if( this != NULL && sueldo > 0)
    {

        this->sueldo = sueldo;
        todoOk = 1;
    }

    return todoOk;

}

int employee_getSueldo(Employee* this,int* sueldo)
{
    int todoOk = 0;

    if( this != NULL && sueldo != NULL )
    {

        *sueldo = this->sueldo;
        todoOk = 1;
    }
    return todoOk;
}


Employee* employee_new()
{

    Employee* this = (Employee*) malloc(sizeof(Employee));

    if( this != NULL)
    {
        this->id = 0;
        strcpy(this->nombre, "");
        strcpy(this->profesion, "");
        this->edad = 0;
        this->sueldo = 0;
    }

    return this;
}


Employee* employee_newParametros(char* idStr,char* nombreStr,char* edadStr, char* profesionStr,char* sueldoStr)
{

    Employee* this;

    if (idStr != NULL && nombreStr != NULL && edadStr != NULL && profesionStr != NULL && sueldoStr != NULL)
    {
        this  = employee_new();

        if( this != NULL)
        {

            if(     !employee_setId(this, atoi(idStr))       ||

                    !employee_setNombre(this, nombreStr) ||

                    !employee_setEdad(this, atoi(edadStr)) ||

                    !employee_setSueldo(this, atoi(sueldoStr)) ||

                    !employee_setProfesion(this,profesionStr)

               )
            {
                free(this);
                this = NULL;
            }
        }
    }

    return this;
}



void mostrarEmpleado(Employee* emp)
{
    if(emp != NULL)
    {
        printf("%d  %s  %d  %s  %d\n", emp->id, emp->nombre, emp->edad,emp->profesion, emp->sueldo);
    }
}







int Employee_showEmployees(Employee* pArrayListEmployee, int sizeList)
{
    Employee* pEmployee;

    int i;
    int retorno = 0;
    char auxNombre[100];
    char auxProfesion[100];
    int auxId;
    int auxEdad;
    int auxSueldo;

    for(i=0; i<sizeList; i++)
    {
        pEmployee = ll_get(pArrayListEmployee, i);
        employee_getNombre(pEmployee, auxNombre);
        employee_getSueldo(pEmployee, &auxSueldo);
        employee_getId(pEmployee, &auxId);
        employee_getEdad(pEmployee, &auxEdad);
        employee_getProfesion(pEmployee, auxProfesion);


        printf("\n%d - %s - %d - %s - %d", auxId, auxNombre, auxEdad, auxProfesion, auxSueldo);
    }

    return retorno;
}




