#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "Employee.h"

/** \brief Parsea los datos los datos de los empleados desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int parser_EmployeeFromText(FILE* pFile, LinkedList* pArrayListEmployee)
{

    //validaciones ac�! o al contructor con parametros ya que deberia validar desde ah�!
    Employee* pEmpleado;
    char bufferInt[1024];
    char bufferNombre[1024];
    char bufferHorasTrabajadas[1024];
    char bufferSueldo[1024];

    int retorno = -1;

    if(pFile != NULL)
    {
        while(!feof(pFile))
        {


            fscanf(pFile, "%[^,],%[^,],%[^,],%[^\n]\n", bufferInt, bufferNombre, bufferHorasTrabajadas, bufferSueldo);


            pEmpleado = employee_newParametros(bufferInt, bufferNombre, bufferHorasTrabajadas, bufferSueldo);

            if(pEmpleado != NULL)

            {
                ll_add(pArrayListEmployee, pEmpleado);
                retorno = 0;
            }
        }
    }

    return retorno;

}

/** \brief Parsea los datos los datos de los empleados desde el archivo data.csv (modo binario).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int parser_EmployeeFromBinary(FILE* pFile, LinkedList* pArrayListEmployee)
{
int retorno = 0;
    int cantidadLeidos;

    pFile = fopen(pFile,"rb");
    if(pFile == NULL)
    {
        printf("\nError al abrir el archivo");
        retorno = -1;
    }
    while(!feof(pFile) && retorno)
    {
        Employee *empleadosBinario = employee_new();
        if(empleadosBinario == NULL)
        {
            printf("\nNo hay memoria disponible");
            retorno = -1;
        }
        cantidadLeidos = fread(empleadosBinario,sizeof(Employee),1,pFile);
        if(cantidadLeidos == 0)
        {
            break;
        }
        ll_add(pArrayListEmployee,empleadosBinario);
    }
    if(fclose(pFile))
    {
        printf("\nNo se pudo cerrar el archivo correctamente");
    }
    return retorno;
}
