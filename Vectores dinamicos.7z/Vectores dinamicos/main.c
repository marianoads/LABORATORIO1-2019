#include <stdio.h>
#include <stdlib.h>



int main()
{
    int* miVector; ///Creo un puntero de tipo entero
    int* auxVector;

    miVector = (int*)calloc(20,sizeof(int)); /// Busco memoria dinamica para un vector de 20 elementos de tipo int,
                                            ///y lo asigno en miVector

    if(miVector == NULL)                        ///Verifico si el espacio en memoria fue creado con exito
    {
        printf("No hay mas lugar en el sistema"); ///Si da NULL, hubo un error en la creacion de espacio
    }

    *miVector = 100; /// En el puntero de vectores Mivector le asigno 100, en el indice 0
    *(miVector+1) = 101; ///Asigno 101 en el indice 1
    printf("*Muestro vector de 10 espacios**\n\n");
    for(int i=0; i<20; i++)
    {
        if(*(miVector+i) != 0)
        {
            printf("%d\n\n", *(miVector+i));  ///Muestro datos
        }
    }
    printf("\n**Pido mas espacio, agrando a 40**\n\n");
    auxVector = (int*)realloc(miVector,40*sizeof(int)); ///Agrego memoria a miVector(20 espacios mas)

    if(auxVector==NULL)
    {
        printf("No hay mas lugar en el sistema");
    }
    else
    {
        miVector=auxVector;         ///Asigno la memoria agrandada a mi vector

        for(int i=2; i<=40; i++) ///Asigno datos del 2 al 40
        {
            *(miVector+i)=i;
        }
        for(int i=2; i<=40; i++)
        {
            if(*(miVector+i) != 0)
            {
                printf("%d\n\n", *(miVector+i));///Muestro datos desde el indice 2 al 40
            }
        }

    }
    printf("\nAchico espacio a 10 elementos\n");
    miVector=(int*)realloc(miVector,10*sizeof(int)); ///Achico el vector a 10 elementos
                                                    ///Cuando achico memoria no hace falta usar el auxVector(Lo guardo directamente)

    if(miVector==NULL){
        printf("No hay espacio");

    }
    else{

    for(int i=0; i<=40; i++)
        {
            if(*(miVector+i) != 0)
            {
                printf("%d\n\n", *(miVector+i));///Muestro datos
            }
        }

    }


    free(miVector);


    printf("\nMuestro datos despues de liberar espacio de memoria de todo el vector\n");
    for(int i=0; i<=40; i++)
        {
            if(*(miVector+i) != 0)
            {
                printf("%d\n\n", *(miVector+i));///
            }
        }






    return 0;
}
