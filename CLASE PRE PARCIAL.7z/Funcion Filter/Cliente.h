typedef struct{
 int dia;
 int mes;
 int anio;
}eFecha;

typedef struct{
  int ID_Cliente;
  eFecha fecha;
  int ID_Llamada;
  int ID_Problema;
  char Solucion[2];

}Cliente;


