#include <stdio.h>
#include <stdlib.h>
#include "Cliente.h"
#include "Controller.h"
#include "LinkedList.h"



int main()
{
    LinkedList* nuevaLista = ll_newLinkedList();

    int opcion;
    char seguir = 's';


    while(seguir == 's')
    {   printf("** MENU FILTROS **\n\n");
        printf("1-Cargar archivo (formato texto)\n");
        printf("2-Imprimir llamadas\n");
        printf("3-Generar archivo de llamadas\n");
        printf("4-Salir\n\n");
        printf("Elija opcion :");
        scanf("%d", &opcion);

        switch(opcion){

    case 1:
        controller_loadFromText("DATOS.csv",nuevaLista);
        system("pause");
        break;
    case 2:
        printf("ID_Llamada       Fecha       Numero_Cliente      ID_Problema   Solucionado");
        controller_showCliente(nuevaLista,ll_len(nuevaLista));

        break;
    case 3:

        break;
    case 4:
        break;
    default:
        break;
        }
       system("cls");
    }



    return 0;
}
