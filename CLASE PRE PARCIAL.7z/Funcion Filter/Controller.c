#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "LinkedList.h"
#include "Cliente.h"
#include "input.h"
#include "parser.h"


/** \brief Carga los datos de los empleados desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_loadFromText(char* path, LinkedList* pArrayListCliente)
{

    FILE *data;
    int retorno= -1;
    data=fopen(path,"r");
    if(!parser_ClienteFromText(data, pArrayListCliente))
    {
        retorno = 0;
        printf("\n\nDatos cargados con exito!\n\n");
    }

    fclose(data);

    return retorno;
}

int controller_showCliente(LinkedList* pArrayListCliente, int sizeList)
{
    Cliente_showClientes(pArrayListCliente, sizeList);

    return 1;
}
