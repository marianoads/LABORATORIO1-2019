#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "persona.h"
#include "utn.h"

int main()
{

    char seguir = 's';
    int cantidadDePersonasRegistradas=0;
    persona_initLista(); ///GUARDO MEMORIA PARA EL VECTOR Y LO INICIALIZO EN 0

    if(lista != NULL)
    {
        do
        {
            ePersona* nuevaPersona;  ///Creo un puntero apuntando a ePersona
            nuevaPersona=new_Persona();


            char auxNombre[50];
            preguntarNombre(auxNombre);
            if(persona_setName(nuevaPersona,auxNombre)){
                printf("\n**El nombre debe tener mas de 3 caracteres**\n\n");
                return 0;
            }


            int edadAux;
            edadAux=preguntarEdad();
            if(persona_setEdad(nuevaPersona,edadAux)){
                printf("\n\n**La edad no es valida**\n\n");
                return 0;
            }


            float auxSalario;
            auxSalario=preguntarSalario();
            if(persona_setSalario(nuevaPersona,auxSalario)){
                printf("\n\n**El salario ingresado no es valido**\n\n");
                return 0;
            }

            persona_addPersona(nuevaPersona);
            cantidadDePersonasRegistradas++;


            printf("\n\nDesea agregar otro usuario? :");
            fflush(stdin);
            scanf("%c", &seguir);

        }
        while(seguir == 's');



    }
    mostrarPersonas(lista,cantidadDePersonasRegistradas);



    return 0;
}

