#include "persona.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*ePersona** lista;
int index=0;
int size=10;*/
//ePersona** lista = (ePersona**)calloc(10,sizeof(ePersona*));

void persona_initLista(void)
{
    size = 2;
    index=0;
    lista = (ePersona**)calloc(size,sizeof(ePersona*));
}

ePersona* new_Persona() ///Constructor por defecto(Porque inicializa en 0)
{
    ePersona* miPersona;
    miPersona= calloc(sizeof(ePersona),1);

    return miPersona;
}

void persona_addPersona(ePersona* p)
{

    lista[index]=p;
    index++;
    if(index>=size)
    {
        printf("no hay mas lugar, redefinimos el array\r\n");
        size=size+2;
        lista = (ePersona**)realloc(lista,sizeof(ePersona*)*size);
    }
}

int persona_setEdad(ePersona* pPersona, int edad)
{
    if(edad>0)
    {
        pPersona->edad = edad;
        return 0; // OK
    }
    return 1; // error
}

int persona_setName(ePersona* pPersona, char* pName)
{
    if(strlen(pName)>=3)
    {
        strcpy(pPersona->nombre,pName);
        return 0;
    }
    return 1;
}

void preguntarNombre(char *nombre)
{

    char auxNombre[50];
    if(!getStringLetras("Ingrese nombre :",auxNombre)){
       printf(" \n\nError, ingrese solo letras!!\n\n");
       return 0;
       }
    else{
        strcpy(nombre,auxNombre);
    }


    return 0;
    /*printf("Ingrese nombre :");

    scanf("%s",auxNombre);*/

}

int preguntarEdad()
{
    int edad;
    printf("Ingrese una edad :");
    scanf("%d",&edad);
    return edad;
}

float preguntarSalario()
{
    float salario;
    printf("Ingrese salario :");
    scanf("%f",&salario);
    return salario;
}

int persona_setSalario(ePersona* pPersona, float salario)
{
    if(salario>0)
    {
        pPersona->salario = salario;
        return 0; // OK
    }
    return 1; // error
}



void persona_toString(ePersona* unaPersona)
{
    printf("Nombre:%s    Edad:%d    Salario:%.2f\n\n",unaPersona->nombre,unaPersona->edad,unaPersona->salario);

}

void mostrarPersonas(ePersona **lista, int cantPersonas){
    int i;
    for(i =0;i<cantPersonas;i++){
        persona_toString(lista[i]);
    }
}




