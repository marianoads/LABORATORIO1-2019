#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "utn.h"

typedef struct{
  int edad;
  char nombre[50];
  float salario;
}ePersona;

int size;
int index;
ePersona** lista;

ePersona* new_Persona();
int persona_setEdad(ePersona* pPersona, int edad);
int persona_setName(ePersona* pPersona, char* pName);
void preguntarNombre(char *auxNombre);
int preguntarEdad();
float preguntarSalario();
int persona_setSalario(ePersona* pPersona, float salario);
void persona_toString(ePersona* unaPersona); ///MUESTRA LOS DATOS DE LA PERSONA
void persona_addPersona(ePersona* p);
void mostrarPersonas(ePersona **lista, int cantPersonas);
