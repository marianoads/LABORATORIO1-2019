#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "Employee.h"

eEmployee* employee_newParametros(char* idStr,char* nombreStr,char* horasTrabajadasStr, char* sueldoStr)
{

    eEmployee* this;

    /*if (idStr != NULL && nombreStr != NULL && horasTrabajadasStr != NULL && sueldoStr != NULL)
    {
        this  = employee_new();

        if( this != NULL)
        {

            if( !employee_setId(this, atoi(idStr))||

                    !employee_setNombre(this, nombreStr) ||

                    !employee_setHorasTrabajadas(this, atoi(horasTrabajadasStr)) ||

                    !employee_setSueldo(this, atoi(sueldoStr)))
            {
                free(this);
                this = NULL;
            }
        }
    }  */

    return this;
}

eEmployee* employee_new()
{

    eEmployee* this = (eEmployee*) malloc(sizeof(eEmployee));

    if( this != NULL)
    {
        //this->id = 0;
        //strcpy(this->nombre, "");
        //this->horasTrabajadas = 0;
        //this->sueldo = 0;
    }

    return this;
}
