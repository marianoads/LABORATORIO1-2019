#ifndef employee_H_INCLUDED
#define employee_H_INCLUDED

typedef struct{
    char programmer[50];
    char analyst[50];
    char tester[50];

}eProfession;

typedef struct {
    int id;
    char name[50];
    float salary[50];
    int age;
    eProfession profession;
    int activo;

}eEmployee;


eEmployee* employee_new();

#endif // employee_H_INCLUDED
