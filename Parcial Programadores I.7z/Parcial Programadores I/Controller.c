#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "Employee.h"
#include "LinkedList.h"
#include "input.h"
#include "parser.h"


/** \brief Carga los datos de los empleados desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_loadFromText(char* path, LinkedList* pArrayListEmployee)
{

    FILE *data;
    int retorno= -1;
    data=fopen(path,"r");
    if(!parser_EmployeeFromText(data, pArrayListEmployee))
    {
        retorno = 0;
        printf("Datos cargados con exito!");
    }

    fclose(data);

    return retorno;
}
