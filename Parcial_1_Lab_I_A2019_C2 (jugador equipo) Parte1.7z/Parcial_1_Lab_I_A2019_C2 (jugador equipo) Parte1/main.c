#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "utn.h"
#define TAM 100

typedef struct
{
    int dia;
    int mes;
    int anio;

} eFecha;

typedef struct
{
    int codigoEquipos;
    char nombreEquipos[50];
    char localidadEquipos[50];
    int ocupado;
} eEquipos;

typedef struct
{
    int codigoJugadores;
    char apellidoJugadores[50];
    char nombreJugadores[50];
    eEquipos codigoEquipoJugadores;
    char sexoJugadores;
    eFecha fechaNacimientoJugadores;
    int ocupado;
} eJugadores;

typedef struct
{
    int codigoReferi;
    char apellidoReferi[50];
    char nombreReferi[50];
    char sexoReferi;
    char emailReferi[50];
    eFecha fechaNacimientoReferi;
    int ocupado;
} eReferi;

typedef struct
{
    int codigoPartido;
    int codigoEquipoVisitante;
    int codigoEquipoLocal;
    eReferi codigoReferi;
    eFecha fechaPartido;
    int ocupado;

} ePartido;

void inicializarVectorEquipos(eEquipos vectorEquipos[],int tam);
void inicializarVectorJugadores(eEquipos vectorJugadores[],int tam);
void inicializarVectorReferis(eEquipos vectorReferis[],int tam);
void inicializarVectorPartidos(eEquipos vectorPartidos[],int tam);
int buscarIndiceLibreEquipos(eEquipos vectorEquipos[],int tam);
int buscarIndiceLibreJugadores(eEquipos vectorJugadores[],int tam);
int buscarIndiceLibreReferis(eEquipos vectorReferis[],int tam);
int buscarIndiceLibrePartidos(eEquipos vectorPartidos[],int tam);

int altaEquipo(eEquipos vectorEquipo[],int tam);
void mostrarEquipos(eEquipos vectorEquipos[],int tam);
int altaJugadores(eJugadores vectorJugadores[],eEquipos vectorEquipos[],int tam);
void mostrarJugadores(eJugadores vectorJugadores[],int tam);


int main()
{

    int opcion;
    int opcionEquipo;
    char seguir = 's';

    eEquipos equipos[TAM];
    eJugadores jugadores[TAM];
    eReferi referis[TAM];

    inicializarVectorEquipos(equipos,TAM);
    inicializarVectorJugadores(jugadores,TAM);
    inicializarVectorReferis(referis,TAM);

    while(seguir == 's')
    {
        printf("*****ABM JUGADOR*****\n\n1-Equipos\n2-Jugadores\n3-Referi\n4-Partidos\n5-Salir\n\nElija opcion (1-5): ");
        scanf("%d",&opcion);

        switch(opcion)
        {
        case 1:
            printf("***Menu Equipos***\n\n1-Alta\n2-Listar\n3-Salir\n\nElija opcion:");
            scanf("%d",&opcionEquipo);
            switch(opcionEquipo){
        case 1:
            altaEquipo(equipos,TAM);
            break;
        case 2:
            mostrarEquipos(equipos,TAM);
            system("pause");
            break;
        case 3:
            seguir == 'n';
            break;
        default:
            printf("Ingrese opcion correcta (1-3");

            }
        break;
        case 2:
            altaJugadores(jugadores,equipos,TAM);
            mostrarJugadores(jugadores,TAM);
            system("pause");
            break;
        case 3:
            break;
        case 4:
            break;
        case 5:
            break;
        default:
            break;
        }
        system("cls");
    };

    return 0;
}

void inicializarVectorEquipos(eEquipos vectorEquipos[],int tam){
    int i;
    for(i=0;i<tam;i++){
        vectorEquipos[i].ocupado=0;
    }
};

void inicializarVectorJugadores(eEquipos vectorJugadores[],int tam){
    int i;
    for(i=0;i<tam;i++){
        vectorJugadores[i].ocupado=0;
    }
};

void inicializarVectorReferis(eEquipos vectorReferis[],int tam){
    int i;
    for(i=0;i<tam;i++){
        vectorReferis[i].ocupado=0;
    }
};

void inicializarVectorPartidos(eEquipos vectorPartidos[],int tam){
    int i;
    for(i=0;i<tam;i++){
        vectorPartidos[i].ocupado=0;
    }
};

int buscarIndiceLibreEquipos(eEquipos vectorEquipos[],int tam){
    int i;
    for(i=0;i<tam;i++){
        if(vectorEquipos[i].ocupado == 0){
            return i;
        }
    }
    return -1;
};

int buscarIndiceLibreJugadores(eEquipos vectorJugadores[],int tam){
    int i;
    for(i=0;i<tam;i++){
        if(vectorJugadores[i].ocupado == 0){
            return i;
        }
    }
    return -1;
};

int buscarIndiceLibreReferis(eEquipos vectorReferis[],int tam){
    int i;
    for(i=0;i<tam;i++){
        if(vectorReferis[i].ocupado == 0){
            return i;
        }
    }
    return -1;
};

int buscarIndiceLibrePartidos(eEquipos vectorPartidos[],int tam){
    int i;
    for(i=0;i<tam;i++){
        if(vectorPartidos[i].ocupado == 0){
            return i;
        }
    }
    return -1;
};

int altaEquipo(eEquipos vectorEquipo[],int tam){
    int static idEquipo=1;
    int indiceLibre;
    char auxNombreEquipo[50];
    char auxLocalidadEquipo[50];

    indiceLibre=buscarIndiceLibreEquipos(vectorEquipo,tam);

    if(indiceLibre==-1){
        printf("\n--NO HAY MAS LUGAR EN EL SISTEMA--\n");
    }
    else{
    vectorEquipo[indiceLibre].codigoEquipos= idEquipo;

    if(!getStringLetras("Ingrese nombre del equipo:", auxNombreEquipo))
        {
            printf("\nIngrese solo letras!!\n\n");
            system("pause");
            return 0;
        }
    if(!getStringLetras("Ingrese localidad :", auxLocalidadEquipo))
        {
            printf("\nIngrese solo letras!!\n\n");
            system("pause");
            return 0;
        }
    strcpy(vectorEquipo[indiceLibre].nombreEquipos,auxNombreEquipo);
    strcpy(vectorEquipo[indiceLibre].localidadEquipos,auxLocalidadEquipo);
    idEquipo++;
    vectorEquipo[indiceLibre].ocupado=1;

    }

};

void mostrarEquipos(eEquipos vectorEquipos[],int tam){
    int i;
    for(i=0;i<tam;i++){
        if(vectorEquipos[i].ocupado==1){
            printf("idEquipo:%d   Nombre: %s   Localidad: %s\n",vectorEquipos[i].codigoEquipos,vectorEquipos[i].nombreEquipos,vectorEquipos[i].localidadEquipos);

        }
    }

}

int altaJugadores(eJugadores vectorJugadores[],eEquipos vectorEquipos[],int tam){
    int static idAuntoincremental=1;
    int indiceLibre;
    char auxNombreJugador[50];
    char auxApellidoJugador[50];




    indiceLibre=buscarIndiceLibreJugadores(vectorJugadores,tam);

    if(indiceLibre==-1){
        printf("\n--NO HAY MAS LUGAR EN EL SISTEMA--\n");
    }
    else{
        vectorJugadores[indiceLibre].codigoJugadores=idAuntoincremental;

        if(!getStringLetras("Ingrese nombre del jugador:", auxNombreJugador))
        {
            printf("\nIngrese solo letras!!\n\n");
            system("pause");
            return 0;
        }
        if(!getStringLetras("Ingrese apellido del jugador:", auxApellidoJugador))
        {
            printf("\nIngrese solo letras!!\n\n");
            system("pause");
            return 0;
        }
        getInt(&vectorJugadores[indiceLibre].codigoEquipoJugadores.codigoEquipos,"Ingrese codigo del equipo","Error, ingrese solo numeros",1,100);

        getChar(&vectorJugadores[indiceLibre].sexoJugadores,"Ingrese sexo","Error ingrese solo un caracter",'a','z');

        getInt(&vectorJugadores[indiceLibre].fechaNacimientoJugadores.dia,"Ingrese dia de nacimiento  (1-31)","Error, ingrese solo numeros",1,31);
        getInt(&vectorJugadores[indiceLibre].fechaNacimientoJugadores.mes,"Ingrese mes de nacimiento (1-12)","Error, ingrese solo numeros",1,12);
        getInt(&vectorJugadores[indiceLibre].fechaNacimientoJugadores.anio,"Ingrese anio de nacimiento (1920-2020)","Error, ingrese solo numeros",1920,2020);

    }
        strcpy(vectorJugadores[indiceLibre].nombreJugadores,auxNombreJugador);
        strcpy(vectorJugadores[indiceLibre].apellidoJugadores,auxApellidoJugador);
        idAuntoincremental++;
        vectorJugadores[indiceLibre].ocupado=1;
}

void mostrarJugadores(eJugadores vectorJugadores[],int tam){
    int i;
    for(i=0;i<tam;i++){
        if(vectorJugadores[i].ocupado==1){
            printf("idJugador:%d   Nombre:%s   Apellido:%s Sexo:%c  Dia:%d Mes:%d Anio:%d",vectorJugadores[i].codigoJugadores,vectorJugadores[i].nombreJugadores,vectorJugadores[i].apellidoJugadores,vectorJugadores[i].sexoJugadores,vectorJugadores[i].fechaNacimientoJugadores.dia,vectorJugadores[i].fechaNacimientoJugadores.mes,vectorJugadores[i].fechaNacimientoJugadores.anio);
        }
    }
}

int altaReferi(eReferi vectorReferi[],eFecha fechaReferi[], int tam){
    int indiceLibre;
    int static idAutoincremental=1;
    char auxNombreReferi[50];
    char auxApellidoReferi[50];

    indiceLibre=buscarIndiceLibreReferis(vectorReferi,tam);

    if(indiceLibre==-1){
        printf("\n--NO HAY MAS LUGAR EN EL SISTEMA--\n");
    }
    else{
        vectorReferi[indiceLibre].codigoReferi=idAuntoincremental;

        if(!getStringLetras("Ingrese nombre del referi:", auxNombreReferi))
        {
            printf("\nIngrese solo letras!!\n\n");
            system("pause");
            return 0;
        }
        if(!getStringLetras("Ingrese apellido del referi:", auxApellidoReferi))
        {
            printf("\nIngrese solo letras!!\n\n");
            system("pause");
            return 0;
        }

        getChar(&vectorReferi[indiceLibre].sexoReferi,"Ingrese sexo","Error ingrese solo un caracter",'a','z');

        getInt(&vectorReferi[indiceLibre].fechaNacimientoJugadores.dia,"Ingrese dia de nacimiento  (1-31)","Error, ingrese solo numeros",1,31);
        getInt(&vectorReferi[indiceLibre].fechaNacimientoJugadores.mes,"Ingrese mes de nacimiento (1-12)","Error, ingrese solo numeros",1,12);
        getInt(&vectorReferi[indiceLibre].fechaNacimientoJugadores.anio,"Ingrese anio de nacimiento (1920-2020)","Error, ingrese solo numeros",1920,2020);

    }
    strcpy(vectorReferi[indiceLibre].nombreReferi,auxNombreReferi);
    strcpy(vectorReferi[indiceLibre].apellidoReferi,auxApellidoReferi);
    idAutoincremental++;
    vectorEquipo[indiceLibre].ocupado=1;

};
