#include <stdio.h>
#include <stdlib.h>



void ordenarArray(float *vec, int tam);
void swap(float* num1,float* num2);

int main()
{
    char seguir='s';
    float numero[50] = {};

    int indice=0;

    do
    {
        printf("Ingrese numero de orden :");   ///Pido que ingrese numero de orden
        scanf("%f",&numero[indice]); ///Guardo

        indice++;           ///incremento indice

        printf("Desea seguir?:");  ///Pido si desea seguir
        fflush(stdin);
        scanf("%c",&seguir);
    }
    while(seguir == 's');

    ordenarArray(numero,50);  ///ORDENO ARRAY CON UNA FUNCION

    for(int i=0; i<50; i++)
    {
        printf("%d - %.2f\n\n",i,numero[i]); ///MUESTRO POR CONSOLA
    }


    return 0;
}

void ordenarArray(float *vec, int tam)  ///METODO BURBUJA + SWAP
{

    for(int i=0; i<tam; i++)
    {
        for(int j=i+1; j<tam; j++)
        {
            if(*(vec+i) < *(vec+j))
            {
                swap(vec+i,vec+j); ///LLAMO A LA FUNCION SWAP QUE INTERCAMBIA 2 NUMEROS
            }
        }
    }
}

void swap(float* num1,float* num2)  ///INGRESO DOS NUMEROS Y LOS INTERCAMBIA
{
    float aux;
    aux=*num1;
    *num1=*num2;
    *num2=aux;

};
