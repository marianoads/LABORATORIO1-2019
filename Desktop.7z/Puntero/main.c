#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define TAM 50

typedef struct
{
    int id;
    char apellido[50];
    int orden;
    int estado;
} ePersona;

void ordenarArray(ePersona* vector, int tam);
void swap(ePersona *a, ePersona *b);
void mostrarPersonas(ePersona* vectorPersonas);
void inicializarVector(ePersona* vector,int tam);
int buscarIndicePersonaLibre(ePersona* vector,int tam);
void pedirDatos(ePersona* vector,int indiceEncontrado);

int main()
{
    char seguir='s';
    int idAutoincremental=9;
    int indiceEncontrado;
    //ePersona vectorPersonas[50] = {};
    ePersona harcodeoPersonas[TAM] = {{1,"Jose",235,1},{2,"Pedro",501,1},{3,"Santaigo",135,1},{4,"Pepe",285,1},{5,"Martin",2235,1},{6,"Sofia",235,1},{7,"Camila",235,1},{8,"Julia",235,1}};

    int indice=8;
    inicializarVector(harcodeoPersonas,TAM);
    do
    {
        indiceEncontrado=buscarIndicePersonaLibre(harcodeoPersonas,TAM); ///Busco un indice libre para cargar datos

        pedirDatos(harcodeoPersonas,indiceEncontrado); ///Pido los datos y los guardo en el indice encontrado

        harcodeoPersonas[indiceEncontrado].id=idAutoincremental++; ///Incremento el id

        harcodeoPersonas[indiceEncontrado].estado=1;

        indice++;           ///incremento



        printf("Desea seguir?:");  ///Pido si desea seguir
        fflush(stdin);
        scanf("%c",&seguir);
    }
    while(seguir == 's');

    printf("\n\n***Ordenamiento por Numero de Id**\n\n");
    mostrarPersonas(harcodeoPersonas);

    ordenarArray(harcodeoPersonas,TAM);

    printf("\n\n***Ordenamiento por Numero de Orden**\n\n");
    mostrarPersonas(harcodeoPersonas);

    return 0;
}
void inicializarVector(ePersona* vector,int tam)
{
    for(int i=0; i<tam; i++)
    {
        vector[i].estado==0;
    }
}

void ordenarArray(ePersona* vector, int tam)
{

    for(int i=0; i<tam; i++)
    {
        for(int j=i+1; j<tam; j++)
        {
            if((vector+i)->orden > ((vector+j)->orden /*vector[i].orden>vector[j].orden*/))
            {
                swap(vector+i,vector+j);
            }
        }
    }
};

void swap(ePersona *a, ePersona *b)
{
    ePersona aux;
    aux = *a;
    *a = *b;
    *b = aux;
};

int buscarIndicePersonaLibre(ePersona* vector,int tam)
{
    for(int i=0; i<tam; i++)
    {
        if(vector[i].estado == 0)
        {
            return i;
        }
    }
    return -1;
};

void mostrarPersonas(ePersona* vectorPersonas)
{
    for(int i=0; i<50; i++)
    {
        if(vectorPersonas[i].estado == 1)
        {
            printf("%d %s %d\n\n",vectorPersonas[i].id,vectorPersonas[i].apellido,vectorPersonas[i].orden); ///MUESTRO POR CONSOLA

        }
    }
}

void pedirDatos(ePersona* vector,int indiceEncontrado)
{
    printf("Ingrese apellido :");
    scanf("%s",vector[indiceEncontrado].apellido);

    printf("Ingrese numero de orden :");
    scanf("%d",&vector[indiceEncontrado].orden);

}




