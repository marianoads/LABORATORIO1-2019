#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "Employee.h"

Employee* employee_new()
{

    Employee* this = (Employee*) malloc(sizeof(Employee));

    if( this != NULL)
    {
        this->id = 0;
        strcpy(this->nombre, "");
        strcpy(this->empresa, "");
        this->edad = 0;
        this->horasTrabajadas = 0;

    }

    return this;
}

int employee_setId(Employee* this,int id)
{

    int todoOk = 0;

    if( this != NULL && id > 0)
    {

        this->id = id;
        todoOk = 1;
    }

    return todoOk;
}

int employee_setHorasTrabajadas(Employee* this,int horasTrabajadas)
{

    int todoOk = 0;

    if( this != NULL && horasTrabajadas > 0)
    {

        this->horasTrabajadas = horasTrabajadas;
        todoOk = 1;
    }

    return todoOk;
}

int employee_setNombre(Employee* this,char* nombre)
{

    int todoOk = 0;

    if( this != NULL && nombre != NULL && strlen(nombre) > 3)
    {

        strcpy(this->nombre, nombre);
        todoOk = 1;
    }

    return todoOk;

}

int employee_setEdad(Employee* this,int edad)
{

    int todoOk = 0;

    if( this != NULL && edad > 18)
    {

        this->edad = edad;
        todoOk = 1;
    }

    return todoOk;
}

int employee_setEmpresa(Employee* this,char* empresa)
{

    int todoOk = 0;

    if( this != NULL && empresa != NULL && strlen(empresa) > 3)
    {

        strcpy(this->empresa, empresa);
        todoOk = 1;
    }

    return todoOk;

}

Employee* employee_newParametros(char* idStr,char* nombreStr,char* empresaStr,char* edadStr,char* horasTrabajadasStr)
{

    Employee* this;

    if (idStr != NULL && nombreStr != NULL && horasTrabajadasStr != NULL && edadStr != NULL && empresaStr != NULL)
    {
        this  = employee_new();

        if( this != NULL)
        {

            if( !employee_setId(this, atoi(idStr))||

                    !employee_setNombre(this, nombreStr) ||

                    !employee_setEmpresa(this, empresaStr) ||

                    !employee_setEdad(this,atoi(edadStr)) ||

                    !employee_setHorasTrabajadas(this, atoi(horasTrabajadasStr))

              )
            {
                free(this);
                this = NULL;
            }
        }
    }

    return this;
}

int employee_getHorasTrabajadas(Employee* this,int* horasTrabajadas)
{

    int todoOk = 0;

    if( this != NULL && horasTrabajadas != NULL )
    {

        *horasTrabajadas = this->horasTrabajadas;
        todoOk = 1;
    }
    return todoOk;

}

int employee_getId(Employee* this,int* id)
{

    int todoOk = 0;

    if( this != NULL && id != NULL )
    {

        *id = this->id;
        todoOk = 1;
    }
    return todoOk;
}

int employee_getEdad(Employee* this,int* edad)
{

    int todoOk = 0;

    if( this != NULL && edad != NULL )
    {

        *edad = this->edad;
        todoOk = 1;
    }
    return todoOk;
}

int employee_getNombre(Employee* this,char* nombre)
{

    int todoOk = 0;

    if( this != NULL && nombre != NULL )
    {

        strcpy(nombre, this->nombre);
        todoOk = 1;
    }

    return todoOk;

}

int employee_getEmpresa(Employee* this,char* empresa)
{

    int todoOk = 0;

    if( this != NULL && empresa != NULL )
    {

        strcpy(empresa, this->empresa);
        todoOk = 1;
    }

    return todoOk;

}

int Employee_showEmployees(Employee* pArrayListEmployee, int sizeList)
{
    Employee* pEmployee;

    int i;
    int retorno = 0;
    char auxNombre[1024];
    char auxEmpresa[1024];
    int auxId;
    int auxEdad;
    int auxHorasTrabajadas;


    for(i=0; i<sizeList; i++)
    {
        pEmployee = ll_get(pArrayListEmployee, i);
        employee_getNombre(pEmployee, auxNombre);
        employee_getEmpresa(pEmployee,auxEmpresa);
        employee_getEdad(pEmployee,&auxEdad);
        employee_getId(pEmployee, &auxId);
        employee_getHorasTrabajadas(pEmployee, &auxHorasTrabajadas);

        printf("\n%d - %s - %s - %d - %d", auxId, auxNombre,auxEmpresa,auxEdad,auxHorasTrabajadas);
    }

    return retorno;
}
