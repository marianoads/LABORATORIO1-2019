#ifndef SOCIOS_H_INCLUDED
#define SOCIOS_H_INCLUDED
int getInt(int* input,char message[],char eMessage[], int lowLimit, int hiLimit);
int getNombre(char* input,char message[],char eMessage[], int lowLimit, int hiLimit);





#endif
