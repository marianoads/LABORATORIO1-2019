#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "LinkedList.h"
#include "Employee.h"
#include "input.h"
#include "parser.h"


/** \brief Carga los datos de los empleados desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_loadFromText(char* path, LinkedList* pArrayListEmployee)
{

    FILE *data;
    int retorno= -1;
    data=fopen(path,"r");
    if(!parser_EmployeeFromText(data, pArrayListEmployee))
    {
        retorno = 0;
        printf("Datos cargados con exito!");
    }

    fclose(data);

    return retorno;
}

/** \brief Carga los datos de los empleados desde el archivo data.csv (modo binario).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_loadFromBinary(char* path, LinkedList* pArrayListEmployee)
{
   int retorno = -1;
    if(!parser_EmployeeFromBinary(path,pArrayListEmployee))
    {
        printf("\nDatos cargados con exito");
        retorno = 0;
    }
    return retorno;
}

/** \brief Alta de empleados
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_addEmployee(LinkedList* pArrayListEmployee)
{
    int retorno = -1;
    Employee* empAux;
    char bufferInt[1024];
    char bufferNombre[1024];
    char bufferHorasTrabajadas[1024];
    char bufferSueldo[1024];

    char idAux;
    char nameAux [25];
    int horaAux;
    int sueldoAux;

    idAux=itoa(ll_len(pArrayListEmployee+1),bufferInt,10);

    system("cls");
    printf("-- Alta de empleado --\n\n");

    getNombre(nameAux,"Ingrese el nombre del empleado :","Error, ingrese un nombre valido",1,25);
    getInt(&horaAux,"Ingrese la cantidad de horas trabajadas en el mes :","Error, ingrese un horario valido",0,300);
    getInt(&sueldoAux,"Ingrese el sueldo del empleado :","Error, ingrese un sueldo valido",10000,100000);


    empAux=employee_newParametros(bufferInt,nameAux,itoa(horaAux,bufferHorasTrabajadas,10),itoa(sueldoAux,bufferSueldo,10));

    if(empAux != NULL)
        {
            empAux->id = pArrayListEmployee->size + 1;
            ll_add(pArrayListEmployee,empAux);
            printf("\n\tEl alta a sido exitosa");
            retorno = 0;
        }





    return retorno;
}

/** \brief Modificar datos de empleado
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_editEmployee(LinkedList* pArrayListEmployee)
{
    int cantLista;
    int idEmp;
    char confirmar;
    int option;
    int encontroEmpleado = 0;
    Employee* pEmp;

    cantLista=ll_len(pArrayListEmployee);

    if(!cantLista)
    {
        printf("\n(!) No existen empleados cargados en el sistema (!)\n");
        system("pause");
    }
    else
    {
        Employee_showEmployees(pArrayListEmployee,ll_len(pArrayListEmployee));
        getInt(&idEmp,"\n\nIngrese el ID del empleado que desea modificar: ","El ID ingresado no es valido", 0, 300);
        for(int i =0; i<cantLista; i++)
        {
            pEmp=ll_get(pArrayListEmployee, i);

            if(pEmp->id==idEmp)
            {
                printf("\n");
                mostrarEmpleado(pEmp);

                encontroEmpleado=1;

                printf("\n\nDeasea modificar el empleado ? (s/n): ");
                fflush(stdin);
                confirmar = getche();
                printf("\n");

                if(tolower(confirmar) == 's')
                {
                    do
                    {
                        system("cls");
                        getInt(&option,"\nIndique la modificacion que desee realizar:\n1- Modificar ID\n2- Modificar nombre\n3- Modificar horas\n4- Modificar sueldo\n5- Salir\n\nOpcion: ","\nIngrese una opcion correcta del 1 al 5\n",1,5);
                        switch(option)
                        {
                        case 1:
                            getInt(&pEmp->id, "\nIngrese el nuevo ID: ","\n Error, id invalido\n",0,300);
                            printf("\n>> ID modificado exitosamente <<\n");
                            system("pause");
                            break;
                        case 2:
                            getNombre(&pEmp->nombre, "\nIngrese el nuevo nombre: ","\n Error, nombre invalido\n",1,25);
                            printf("\n>> Nombre modificado exitosamente <<\n");
                            system("pause");
                            break;
                        case 3:
                            getInt(&pEmp->horasTrabajadas, "\nIngrese la nueva cantidad de horas: ","\n Error, horas trabajadas invalidas\n",0,300);
                            printf("\n>> Cantidad de horas modificada exitosamente <<\n");
                            system("pause");
                            break;
                        case 4:
                            getInt(&pEmp->sueldo , "\nIngrese el nuevo sueldo: ","\nError, sueldo invalido\n",10000,100000);
                            printf("\n>> Sueldo modificado exitosamente <<\n");
                            system("pause");
                        default:
                            printf("\nVolviendo al menu principal\n");
                        }
                    }
                    while(option!=5);


                    system("pause");
                }
                break;
            }
        }
        if(!encontroEmpleado)
        {
            printf("\nNo fue posible encontrar a un empleado con ese ID\n");
            system("pause");
        }
    }
    return 1;
}

/** \brief Baja de empleado
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_removeEmployee(LinkedList* pArrayListEmployee)
{
  int cantLista;
    int idEmp;
    char confirmar;
    int encontroEmpleado = 0;
    Employee* pEmp;

    cantLista=ll_len(pArrayListEmployee);

    if(!cantLista)
    {
        printf("\n(!) No existen empleados cargados en el sistema (!)\n");
        system("pause");
    }
    else
    {
        Employee_showEmployees(pArrayListEmployee,ll_len(pArrayListEmployee));
        getInt(&idEmp,"\n\nPor favor ingrese el ID del empleado que desea dar de baja: ","El ID ingresado no es valido", 0, 5000);

        for(int i =0; i<cantLista; i++)
        {
            pEmp=ll_get(pArrayListEmployee, i);

            if(pEmp->id==idEmp)
            {
                printf("\n");
                mostrarEmpleado(pEmp);

                encontroEmpleado=1;

                printf("\n\nDesea dar de baja este empleado? (s/n): ");
                fflush(stdin);
                confirmar = getche();
                printf("\n");

                if(tolower(confirmar) == 's')
                {
                    ll_remove(pArrayListEmployee, i);
                    printf("\nEmpleado dado de baja exitosamente!!\n");
                    system("pause");
                }
                break;
            }
        }
        if(!encontroEmpleado)
        {
            printf("\nNo fue posible encontrar a un empleado con ese ID\n");
            system("pause");
        }
    }
    return 1;
}

/** \brief Listar empleados
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_ListEmployee(LinkedList* pArrayListEmployee)
{

    return 0;
}

/** \brief Ordenar empleados
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_sortEmployee(LinkedList* pArrayListEmployee)
{
int i , j;
    Employee *pI;
    Employee *pJ;
    Employee *aux;
    int cantidadElementos = pArrayListEmployee->size;

    if(cantidadElementos > 0)
    {
        for(i=0;i<cantidadElementos-1;i++)
        {
            pI = ll_get(pArrayListEmployee,i);
            for(j=i+1;j<cantidadElementos;j++)
            {
                pJ = ll_get(pArrayListEmployee,j);
                if(strcmp(pI->nombre,pJ->nombre) > 0)
                {
                    aux = pI;
                    pI = pJ;
                    pJ = aux;

                }
            }
        }
    }
    else
    {
        printf("\nNo hay datos cargados");
    }
    return 1;
}

/** \brief Guarda los datos de los empleados en el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_saveAsText(char* path, LinkedList* pArrayListEmployee)
{
    FILE *pFile;
    pFile = fopen(path,"w");
    int cantidadLetras;
    int cantidadLista = ll_len(pArrayListEmployee);
    if(pFile == NULL)
    {
        printf("\nError al abrir el archivo");
        return 0;
    }
    int i = 0;
    fprintf(pFile,"id,nombre,horasTrabajadas,sueldo\n");
    while(i <= cantidadLista)
    {
        Employee *p = ll_get(pArrayListEmployee,i);
        if(p != NULL)
        {
            cantidadLetras=fprintf(pFile,"%d,%s,%d,%d\n",p->id,p->nombre,p->horasTrabajadas,p->sueldo);
        }
        if(cantidadLetras == 0)
        {
            break;
        }
        i++;

    }
    fclose(pFile);
    ll_clear(pArrayListEmployee);
    printf("\nSe han guardado los datos");

    return 1;
}

/** \brief Guarda los datos de los empleados en el archivo data.csv (modo binario).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_saveAsBinary(char* path, LinkedList* pArrayListEmployee)
{
    FILE* pBin;

    int listSize;
    Employee* pEmpAux;

    pBin=fopen(path,"wb");

    listSize = ll_len(pArrayListEmployee);

    if(pBin==NULL)
    {
        printf("\n(!) Error al escribir el archivo binario (!)");
        system("pause");
    }
    else
    {
        for(int i=0; i < listSize; i++)
        {
            pEmpAux = ll_get(pArrayListEmployee, i);
            fwrite((void*)pEmpAux,sizeof(Employee),1,pBin);
        }
        printf("\n>> Archivo binario guardado exitosamente <<\n");
        system("pause");
    }

    fclose(pBin);

    return 1;
}

int controller_showEmployees(LinkedList* pArrayListEmployee, int sizeList)
{
    Employee_showEmployees(pArrayListEmployee, sizeList);

    return 1;
}

