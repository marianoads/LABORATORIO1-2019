#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "LinkedList.h"
#include "Employee.h"
#include "input.h"
#include "parser.h"


/** \brief Carga los datos de los empleados desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_loadFromText(char* path, LinkedList* pArrayListEmployee)
{

    FILE *data;
    int retorno= -1;
    data=fopen(path,"r");
    if(!parser_EmployeeFromText(data, pArrayListEmployee))
    {
        retorno = 0;
        printf("Datos cargados con exito!");
    }

    fclose(data);

    return retorno;
}






/** \brief Guarda los datos de los empleados en el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 */

int controller_saveAsText(char* path, LinkedList* pArrayListEmployee)
{
    FILE *pFile;
    pFile = fopen(path,"w");
    int cantidadLetras;
    int cantidadLista = ll_len(pArrayListEmployee);
    if(pFile == NULL)
    {
        printf("\nError al abrir el archivo");
        return 0;
    }
    int i = 0;
    fprintf(pFile,"id,nombre,edad,profesion,sueldo\n");
    while(i <= cantidadLista)
    {
        Employee *p = ll_get(pArrayListEmployee,i);
        if(p != NULL)
        {
            cantidadLetras=fprintf(pFile,"%d,%s,%d,%s,%d\n",p->id,p->nombre,p->edad,p->profesion,p->sueldo);
        }
        if(cantidadLetras == 0)
        {
            break;
        }
        i++;

    }
    fclose(pFile);
    ll_clear(pArrayListEmployee);
    printf("\nSe han guardado los datos");

    return 1;
}



int controller_showEmployees(LinkedList* pArrayListEmployee, int sizeList)
{
    Employee_showEmployees(pArrayListEmployee, sizeList);

    return 1;
}

