#ifndef employee_H_INCLUDED
#define employee_H_INCLUDED


typedef struct {
    int id;
    char nombre[50];
    int sueldo;
    int edad;
    char profesion[50];

}Employee;



Employee* employee_new();
Employee* employee_newParametros(char* idStr,char* nombreStr,char* sueldoStr, char* edadStr,char* profesionStr);
void employee_delete();

int employee_setId(Employee* this,int id);
int employee_getId(Employee* this,int* id);

int employee_setNombre(Employee* this,char* nombre);
int employee_getNombre(Employee* this,char* nombre);

int employee_setEdad(Employee* this,int edad);
int employee_getEdad(Employee* this,int* edad);

int employee_setProfesion(Employee* this,char* profesion);
int employee_getProfesion(Employee* this,char* profesion);


int employee_setSueldo(Employee* this,int sueldo);
int employee_getSueldo(Employee* this,int* sueldo);

void menuInformes(Employee *pArrayListEmployee);

void mostrarEmpleado(Employee* emp);
int ordenarXSueldo( void* emp1, void* emp2);
int ordenarXHoras( void* emp1, void* emp2);
int ordenarXNombre( void* emp1, void* emp2);
int ordenarXId( void* emp1, void* emp2);
void mostrarPersonasQueSuperenLos30000(Employee *pArrayListEmployee,int tam);
void mostrarLos15MejoresPagos(Employee *pArrayListEmployee);
int asignarIdANuevoEmpleado(Employee *pArrayListEmployee);

int Employee_showEmployees(Employee* pArrayListEmployee, int sizeList);


#endif // employee_H_INCLUDED
