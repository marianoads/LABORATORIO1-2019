#include <stdio.h>
#include <stdlib.h>


typedef struct{
    int legajo;
    int edad;
    float altura;

}ePersona;

ePersona* new_Persona();
ePersona* new_Persona_Parametros(int ,int ,float );
int mostrarPersona(ePersona*);
int delete_Persona(ePersona*);


