#include <stdio.h>
#include <stdlib.h>
#include "persona.h"
ePersona* new_Persona() ///Constructor por defecto(Porque inicializa en 0)
{
    ePersona* miPersona;
    miPersona= calloc(sizeof(ePersona),1);

    return miPersona;
}

int mostrarPersona(ePersona* unaPersona){
    int retorno=-1;
    if(unaPersona == NULL){
        printf("No hay espacio en memoria");
    }
    else{
        printf("%d %d %.2f",unaPersona->legajo,unaPersona->edad,unaPersona->altura);
        retorno=1;

    }
    return retorno;
}

int delete_Persona(ePersona* pPersona){
    int retorno=-1;

    if(pPersona == NULL){
        printf("No hay espacio en memoria");
    }
    else{
        free(pPersona);
        retorno=0;

    }
    return retorno;
}

ePersona* new_Persona_Parametros(int legajo,int edad,float altura){
    ePersona* miPersona;
    miPersona= new_Persona();
    if(miPersona != NULL){
     miPersona->legajo=legajo;
    miPersona->edad=edad;
    miPersona->altura=altura;


    }
return miPersona;
};
