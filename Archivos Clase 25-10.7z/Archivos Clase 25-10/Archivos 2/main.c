#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct{
  int id;
    char nombre [50];
    int horasTrabajadas;
    float sueldo;
}eEmpleado;


int main()
{
    FILE* pArchive;
    int i=0;
    char id[50];
    char nombre [50];
    char horasTrabajadas[50];
    char sueldo[50];

    eEmpleado listaEmpleado[102];
    eEmpleado nuevoEmpleado;

    pArchive = fopen("data.csv","r");

                ///fscanf: La mascara la creamos nosotros(Configurar el formato del split)
                ///Voy a leer de esta cadena hasta la coma, y voy a excluir la coma. Y la ultima coma voy a poner el dato que voy a leer.

        fscanf(pArchive,"%[^,],%[^,],%[^,],%[^\n]\n",id,nombre,horasTrabajadas,sueldo); ///Es para leer la primer linea
        printf("%s      %s       %s      %s\n",id,nombre,horasTrabajadas,sueldo);
    while(!feof(pArchive)){
        fscanf(pArchive,"%[^,],%[^,],%[^,],%[^\n]\n",id,nombre,horasTrabajadas,sueldo); ///Leo desde donde dejo el indicador el fscanf anterior

        nuevoEmpleado.id=atoi(id);
        strcpy(nuevoEmpleado.nombre,nombre);
        nuevoEmpleado.horasTrabajadas=atoi(horasTrabajadas);
        nuevoEmpleado.sueldo=atof(sueldo);

        listaEmpleado[i]=nuevoEmpleado;
        i++;
    }



    fclose(pArchive);

    for(i=0;i<101;i++){
        printf("Id:%d Nombre:%s HorasTrabajadas:%d Sueldo:%.2f\n",listaEmpleado[i].id,listaEmpleado[i].nombre,listaEmpleado[i].horasTrabajadas,listaEmpleado[i].sueldo);
    }
    return 0;

}
