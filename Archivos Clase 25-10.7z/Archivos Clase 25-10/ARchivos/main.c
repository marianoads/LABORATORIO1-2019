#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE*  pArchivo;
    char miNombre[50];
    //char nombreHarcodeado[50] = "Jose";

    /*pArchivo=fopen("miNombre.txt","w");                               ///Creo un archivo en modo texto

    fprintf(pArchivo,"Mariano"); ///Permite escribir archivos de txto ///Escribo Mariano en el archivo
    fprintf(pArchivo,"%s",nombreHarcodeado);*/
    //fwrite(); ///Permite escribir archivos binarios

    pArchivo=fopen("C:\\Users\\alumno\\Desktop\\ARchivos\\miNombre.txt","r");  ///Abro el archivo
        while(!feof(pArchivo)){ ///Mientras no sea el final del archivo, leo una linea
            fgets(miNombre,50,pArchivo);   ///Leo los datos del archivo y lo guardo en miNombre
            printf("Mi nombre es :%s", miNombre);
        }



    fclose(pArchivo); ///Cierro el archivo



    return 0;
}
